package org.firstinspires.ftc.teamcode;

import java.util.List;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaCurrentGame;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.tfod.Tfod;

@Autonomous(name = "rauton_ToJava (Blocks to Java)", preselectTeleOp = "REDFinalTeleOpCodeDriveBaseCode")
public class rauton_ToJava extends LinearOpMode {

  private Tfod tfod;
  private VuforiaCurrentGame vuforiaFreightFrenzy;
  private DcMotor elevator;
  private DcMotor frontright;
  private DcMotor backleft;
  private DcMotor backright;
  private CRServo frontleft;
  private CRServo carousel;
  
  String duckPos;

  /**
   * Describe this function...
   */
  // TODO: Enter the correct return type for function named findDuckPos
  private String findDuckPos(int duckPosTime) {
    ElapsedTime internalDuckTimer;
    Recognition recog;
    float recogCenter;

    duckPos = "rightBarcode";
    internalDuckTimer = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);
    List<Recognition> recog_list = tfod.getRecognitions();
    for (Recognition recog_item : recog_list) {
      recog = recog_item;
      if (recog.getLabel().equals("Duck") && recog.getHeight() >= 80) {
        while (opModeIsActive() && internalDuckTimer.milliseconds() < duckPosTime) {
          recogCenter = (recog.getLeft() + recog.getRight()) / 2;
          if (recogCenter > recog.getImageWidth() / 2) {
            duckPos = "centerBarcode";
          } else {
            duckPos = "leftBarcode";
          }
        }
      }
    }
    return duckPos;
  }
  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {

    tfod = new Tfod();
    vuforiaFreightFrenzy = new VuforiaCurrentGame();
    elevator = hardwareMap.get(DcMotor.class, "elevator");
    frontright = hardwareMap.get(DcMotor.class, "front-right");
    backleft = hardwareMap.get(DcMotor.class, "back-left");
    backright = hardwareMap.get(DcMotor.class, "back-right");
    frontleft = hardwareMap.get(CRServo.class, "front-left");
    carousel = hardwareMap.get(CRServo.class, "carousel");

    // Put initialization blocks here.
    initializeMotors();
    initializeTF();
    waitForStart();
    if (opModeIsActive()) {
      // TODO: Duck detection
      duckPos = findDuckPos(2000);
      telemetry.addData("key", duckPos);
      telemetry.update();
      strafe(225, 355, 0.5);
      turnRobot(1200, "left");
      strafe(270, 900, 0.3);
      strafe(90, 375, 0.5);
      turnRobot(100, "right");
      elevator2(duckPos);
      strafe(270, 500, 0.2);
      turnRobot(1100, "right");
      strafe(0, 1100, 0.3);
      strafe(180, 120, 0.2);
      strafe(90, 1000, 0.3);
      strafe(93, 2200, 0.3);
      // should be in warehouse
      telemetry.update();
    }

    tfod.close();
    vuforiaFreightFrenzy.close();
  }

  /**
   * Describe this function...
   */
  private void initializeTF() {
    // Initialize Vuforia.
    vuforiaFreightFrenzy.initialize(
        "", // vuforiaLicenseKey
        hardwareMap.get(WebcamName.class, "Webcam 1"), // cameraName
        "", // webcamCalibrationFilename
        true, // useExtendedTracking
        true, // enableCameraMonitoring
        VuforiaLocalizer.Parameters.CameraMonitorFeedback.NONE, // cameraMonitorFeedback
        0, // dx
        0, // dy
        0, // dz
        AxesOrder.XZY, // axesOrder
        90, // firstAngle
        90, // secondAngle
        0, // thirdAngle
        true); // useCompetitionFieldTargetLocations
    // Set min confidence threshold to 0.7
    tfod.initialize(vuforiaFreightFrenzy, (float) 0.6, true, true);
    // Initialize TFOD before waitForStart.
    // Init TFOD here so the object detection labels are visible
    // in the Camera Stream preview window on the Driver Station.
    tfod.activate();
    // Enable following block to zoom in on target.
    tfod.setZoom(1, 16 / 9);
    telemetry.addData("DS preview on/off", "3 dots, Camera Stream");
    telemetry.addData(">", "Press Play to start");
    telemetry.update();
  }

  /**
   * Describe this function...
   */
  private void elevator2(
      // TODO: Enter the type for argument named elevatorLevel
      String elevatorLevel) {
    elevator.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    elevator.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    if (elevatorLevel == "leftBarcode") {
      telemetry.addData("left", "left");
      telemetry.update();
      elevator.setTargetPosition(550);
      elevator.setMode(DcMotor.RunMode.RUN_TO_POSITION);
      ((DcMotorEx) elevator).setVelocity(800);
      while (elevator.isBusy()) {
      }
      intake(1500);
    } else if (elevatorLevel == "centerBarcode") {
      telemetry.addData("center", "center");
      telemetry.update();
      elevator.setTargetPosition(930);
      elevator.setMode(DcMotor.RunMode.RUN_TO_POSITION);
      ((DcMotorEx) elevator).setVelocity(800);
      while (elevator.isBusy()) {
      }
      intake(1500);
    } else {
      telemetry.addData("right", "right");
      telemetry.update();
      elevator.setTargetPosition(1350);
      elevator.setMode(DcMotor.RunMode.RUN_TO_POSITION);
      ((DcMotorEx) elevator).setVelocity(800);
      while (elevator.isBusy()) {
      }
      strafe(90, 200, 0.2);
      intake(1500);
      strafe(270, 200, 0.2);
    }
    while (elevator.getCurrentPosition() > 0) {
      elevator.setTargetPosition(0);
    }
    elevator.setPower(0);
  }

  /**
   * Describe this function...
   */
  private void turnRobot(int turnTime, String turnDir) {
    ElapsedTime internalTurnTimer;

    internalTurnTimer = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);
    while (internalTurnTimer.milliseconds() < turnTime) {
      if (turnDir.equals("left")) {
        frontright.setPower(0.4);
        backleft.setPower(0.4);
      } else {
        backright.setPower(0.4);
        frontleft.setPower(0.4);
      }
    }
  }
  
  private void intake(int x) {
    
  }

  /**
   * Describe this function...
   */
  private void initializeMotors() {
    backright.setDirection(DcMotorSimple.Direction.REVERSE);
    backleft.setDirection(DcMotorSimple.Direction.REVERSE);
    frontright.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
    backleft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
    backright.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
  }

  /**
   * Describe this function...
   */
  private void strafe(int strafeAngle, int strafeTime, double motorSpeed) {
    // TODO: Enter the type for variable named strafeYaw
    int strafeYaw;
    // TODO: Enter the type for variable named Yaw_Angle
    int Yaw_Angle;
    double Vertical;
    double horizontal;
    ElapsedTime internalStrafeTimer;
    int motorOffset;

    // angle: value btw 0 and 360
    Vertical = Math.sin(strafeAngle / 180 * Math.PI);
    horizontal = Math.cos(strafeAngle / 180 * Math.PI);
    internalStrafeTimer = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);
    motorOffset = 0;
    while (opModeIsActive() && internalStrafeTimer.milliseconds() < strafeTime) {
      frontright.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
      backright.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
      frontleft.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
      backleft.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
    }
    stopMotors();
  }

  /**
   * Describe this function...
   */
  private void stopMotors() {
    ElapsedTime internalStopTimer;

    internalStopTimer = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);
    while (opModeIsActive() && internalStopTimer.milliseconds() < 700) {
      frontleft.setPower(0);
      frontright.setPower(0);
      backleft.setPower(0);
      backright.setPower(0);
    }
  }

  /**
   * Describe this function...
   */
  private void rotateCarousel(
      // TODO: Enter the type for argument named carouselTime
      int carouselTime) {
    ElapsedTime internalCarouselTimer;

    internalCarouselTimer = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);
    carousel.setPower(0);
    while (opModeIsActive() && internalCarouselTimer.milliseconds() < carouselTime) {
      carousel.setPower(1);
      frontright.setPower(-0.1);
      backleft.setPower(-0.1);
      backright.setPower(-0.1);
      frontleft.setPower(-0.1);
    }
    carousel.setPower(0);
  }
}
