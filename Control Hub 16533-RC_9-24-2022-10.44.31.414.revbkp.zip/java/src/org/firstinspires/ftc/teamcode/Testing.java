package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.DcMotor;

@Autonomous(name = "Testing")
public class Testing extends LinearOpMode {

  private DcMotor motor0;

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    motor0 = hardwareMap.get(DcMotor.class, "front-right");

    // Put initialization blocks here.
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        // Put loop blocks here.
        moveMotor(motor0, 0.3f);
        telemetry.update();
      }
    }
  }

  /**
   * Describe this function...
   */
  private void moveMotor(DcMotor motor, float power) {
    motor.setPower(power);
  }
}
