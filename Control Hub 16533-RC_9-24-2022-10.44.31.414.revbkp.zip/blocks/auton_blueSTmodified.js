var duckPosTime, duckPos, internalDuckTimer, recog, recogCenter, elevatorLevel, strafeAngle, strafeTime, motorSpeed, intakeTime, carouselTime, internalCarouselTimer, internalStopTimer, strafeYaw, Yaw_Angle, Vertical, horizontal, internalStrafeTimer, motorOffset;

/**
 * Describe this function...
 */
function findDuckPos(duckPosTime) {
}

/**
 * Describe this function...
 */
function elevator(elevatorLevel) {
  elevatorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  elevatorAsDcMotor.setZeroPowerBehavior("BRAKE");
  if (elevatorLevel == 'leftBarcode') {
    telemetryAddTextData('left', 'left');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(750);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (elevatorAsDcMotor.isBusy()) {
    }
    intake(1500);
    strafe(270, 200, 0.2);
  } else if (elevatorLevel == 'centerBarcode') {
    telemetryAddTextData('center', 'center');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(1025);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (elevatorAsDcMotor.isBusy()) {
    }
    intake(1500);
    strafe(270, 200, 0.2);
  } else {
    telemetryAddTextData('right', 'right');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(1500);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (elevatorAsDcMotor.isBusy()) {
    }
    strafe(90, 200, 0.2);
    intake(1500);
    strafe(270, 200, 0.2);
  }
  while (elevatorAsDcMotor.getCurrentPosition() > 0) {
    elevatorAsDcMotor.setTargetPosition(0);
  }
  elevatorAsDcMotor.setPower(0);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  initializeMotors();
  initializeTF();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    strafe(180, 600, 0.5);
    strafe(90, 1250, 0.3);
    strafe(180, 1400, 0.3);
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function initializeTF() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', true, true, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodAccess.initialize(vuforiaCurrentGameAccess, 0.6, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodAccess.activate();
  tfodAccess.setZoom(1, 16 / 9);
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
}

/**
 * Describe this function...
 */
function strafe(strafeAngle, strafeTime, motorSpeed) {
  Vertical = Math.sin(strafeAngle / 180 * Math.PI);
  horizontal = Math.cos(strafeAngle / 180 * Math.PI);
  internalStrafeTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  motorOffset = 0;
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalStrafeTimer) < strafeTime) {
    frontrightAsDcMotor.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
    backrightAsDcMotor.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
    frontleftAsCRServo.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
    backleftAsDcMotor.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
  }
  stopMotors();
}

/**
 * Describe this function...
 */
function intake(intakeTime) {
}

/**
 * Describe this function...
 */
function initializeMotors() {
  backrightAsDcMotor.setDirection("REVERSE");
  backleftAsDcMotor.setDirection("REVERSE");
  frontrightAsDcMotor.setDirection("REVERSE");
  frontrightAsDcMotor.setZeroPowerBehavior("FLOAT");
  backleftAsDcMotor.setZeroPowerBehavior("FLOAT");
  backrightAsDcMotor.setZeroPowerBehavior("FLOAT");
  elevatorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  elevatorAsDcMotor.setZeroPowerBehavior("BRAKE");
}

/**
 * Describe this function...
 */
function rotateCarousel(carouselTime) {
  internalCarouselTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  carouselAsCRServo.setPower(0);
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalCarouselTimer) < carouselTime) {
    carouselAsCRServo.setPower(-1);
  }
  carouselAsCRServo.setPower(0);
}

/**
 * Describe this function...
 */
function stopMotors() {
  internalStopTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalStopTimer) < 700) {
    frontleftAsCRServo.setPower(0);
    frontrightAsDcMotor.setPower(0);
    backleftAsDcMotor.setPower(0);
    backrightAsDcMotor.setPower(0);
  }
}
