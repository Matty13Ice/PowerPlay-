var duckPosTime, duckPos, internalDuckTimer, recog, recogCenter, elevatorLevel, strafeAngle, strafeTime, motorSpeed, intakeTime, turnTime, turnDir, carouselTime, internalCarouselTimer, strafeYaw, Yaw_Angle, Vertical, horizontal, internalStrafeTimer, motorOffset;

/**
 * Describe this function...
 */
function findDuckPos(duckPosTime) {
}

/**
 * Describe this function...
 */
function elevator(elevatorLevel) {
  elevatorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  elevatorAsDcMotor.setZeroPowerBehavior("BRAKE");
  if (elevatorLevel == 'leftBarcode') {
    telemetryAddTextData('left', 'left');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(750);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (elevatorAsDcMotor.isBusy()) {
    }
    intake(1500);
    strafe(270, 200, 0.2);
  } else if (elevatorLevel == 'centerBarcode') {
    telemetryAddTextData('center', 'center');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(1025);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (elevatorAsDcMotor.isBusy()) {
    }
    intake(1500);
    strafe(270, 200, 0.2);
  } else {
    telemetryAddTextData('right', 'right');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(1500);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (elevatorAsDcMotor.isBusy()) {
    }
    strafe(90, 200, 0.2);
    intake(1500);
    strafe(270, 200, 0.2);
  }
  while (elevatorAsDcMotor.getCurrentPosition() > 0) {
    elevatorAsDcMotor.setTargetPosition(0);
  }
  elevatorAsDcMotor.setPower(0);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  initializeMotors();
  initializeTF();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    duckPos = findDuckPos(2000);
    telemetryAddTextData('key', duckPos);
    telemetry.update();
    strafe(225, 335, 0.5);
    turnRobot(1200, 'left');
    strafe(270, 900, 0.3);
    strafe(90, 375, 0.5);
    turnRobot(100, 'right');
    elevator(duckPos);
    strafe(270, 500, 0.2);
    turnRobot(1100, 'right');
    strafe(0, 1100, 0.3);
    strafe(180, 120, 0.2);
    strafe(90, 1000, 0.3);
    strafe(93, 2200, 0.3);
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function initializeTF() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', true, true, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodAccess.initialize(vuforiaCurrentGameAccess, 0.6, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodAccess.activate();
  tfodAccess.setZoom(1, 16 / 9);
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
}

/**
 * Describe this function...
 */
function strafe(strafeAngle, strafeTime, motorSpeed) {
  Vertical = Math.sin(strafeAngle / 180 * Math.PI);
  horizontal = Math.cos(strafeAngle / 180 * Math.PI);
  internalStrafeTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  motorOffset = 0;
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalStrafeTimer) < strafeTime) {
    frontrightAsDcMotor.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
    backrightAsDcMotor.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
    frontleftAsCRServo.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
    backleftAsDcMotor.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
  }
  stopMotors();
}

/**
 * Describe this function...
 */
function intake(intakeTime) {
}

/**
 * Describe this function...
 */
function initializeMotors() {
}

/**
 * Describe this function...
 */
function turnRobot(turnTime, turnDir) {
  telemetry.addNumericData('yooyoo!', 1738);
  telemetry.update();
}

/**
 * Describe this function...
 */
function stopMotors() {
}

/**
 * Describe this function...
 */
function rotateCarousel(carouselTime) {
  internalCarouselTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  carouselAsCRServo.setPower(0);
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalCarouselTimer) < carouselTime) {
    carouselAsCRServo.setPower(-1);
  }
  carouselAsCRServo.setPower(0);
}


duckPos = 'rightBarcode';

internalDuckTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");

while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalDuckTimer) < duckPosTime) {
}

var recog_list = JSON.parse(tfodAccess.getRecognitions());
for (var recog_index in recog_list) {
  recog = recog_list[recog_index];
}

recogCenter = (recog.Left + recog.Right) / 2;

if (false) {
}

false && false;

recog.Label == 0;
