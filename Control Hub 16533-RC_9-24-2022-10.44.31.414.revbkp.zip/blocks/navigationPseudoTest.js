var IMU_Parameters, time, Third_Yaw_Angle, First_Yaw_Angle, Second_Yaw_Angle;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  IMU_Parameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setSensorMode(IMU_Parameters, "IMU");
  imuAsBNO055IMU.initialize(IMU_Parameters);
  telemetryAddTextData('Status', 'IMU initialized, calibration started.');
  telemetry.update();
  linearOpMode.sleep(1000);
  while (!IMU_Calibrated()) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetry.update();
  linearOpMode.waitForStart();
  time = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  while (!(time >= 2000 || linearOpMode.isStopRequested())) {
    Third_Yaw_Angle = orientationAccess.getThirdAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "XYZ", "DEGREES"));
    telemetry.addNumericData('Third Yaw Angle', Third_Yaw_Angle);
    telemetry.update();
  }
  while (!(First_Yaw_Angle <= -90 || Second_Yaw_Angle <= -90 || Third_Yaw_Angle <= -90 || linearOpMode.isStopRequested())) {
    Third_Yaw_Angle = orientationAccess.getThirdAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "XYZ", "DEGREES"));
    telemetry.addNumericData('Third Yaw Value', Third_Yaw_Angle);
    telemetry.update();
  }
  linearOpMode.sleep(1000);
}

/**
 * Function that becomes true when gyro is calibrated and
 * reports calibration status to Driver Station in the meantime.
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
  return imuAsBNO055IMU.isGyroCalibrated();
}
