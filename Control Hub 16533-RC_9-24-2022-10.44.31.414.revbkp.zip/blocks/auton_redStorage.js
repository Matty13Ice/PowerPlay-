var duckPosTime, elevatorLevel, strafeAngle, strafeTime, motorSpeed, intakeTime, carouselTime, turnTime, turnDir, duckPos, internalIntakeTimer, internalCarouselTimer, internalStopTimer, internalTurnTimer, strafeYaw, internalDuckTimer, Yaw_Angle, Vertical, horizontal, recog, internalStrafeTimer, motorOffset;

/**
 * Describe this function...
 */
function findDuckPos(duckPosTime) {
  duckPos = 'rightBarcode';
  internalDuckTimer = elapsedTimeAccess.create_withResolution("SECONDS");
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalDuckTimer) < duckPosTime) {
    var recog_list = JSON.parse(tfodAccess.getRecognitions());
    for (var recog_index in recog_list) {
      recog = recog_list[recog_index];
      if (recog.Label == 'Duck' && recog.Height >= 80) {
        if (recog.Left + recog.Right > recog.ImageWidth) {
          duckPos = 'centerBarcode';
        } else {
          duckPos = 'leftBarcode';
        }
      }
    }
  }
  return duckPos;
}

/**
 * Describe this function...
 */
function initializeMotors() {
  backrightAsDcMotor.setDirection("REVERSE");
  backleftAsDcMotor.setDirection("REVERSE");
  frontrightAsDcMotor.setDirection("REVERSE");
  frontrightAsDcMotor.setZeroPowerBehavior("FLOAT");
  backleftAsDcMotor.setZeroPowerBehavior("FLOAT");
  backrightAsDcMotor.setZeroPowerBehavior("FLOAT");
  elevatorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  elevatorAsDcMotor.setZeroPowerBehavior("BRAKE");
}

/**
 * Describe this function...
 */
function elevator(elevatorLevel) {
  elevatorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  elevatorAsDcMotor.setZeroPowerBehavior("BRAKE");
  if (elevatorLevel == 'leftBarcode') {
    telemetryAddTextData('left', 'left');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(550);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (linearOpMode.opModeIsActive() && elevatorAsDcMotor.isBusy()) {
    }
    intake(1500);
    strafe(270, 200, 0.2);
  } else if (elevatorLevel == 'centerBarcode') {
    telemetryAddTextData('center', 'center');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(970);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (linearOpMode.opModeIsActive() && elevatorAsDcMotor.isBusy()) {
    }
    intake(1500);
    strafe(270, 200, 0.2);
  } else {
    telemetryAddTextData('right', 'right');
    telemetry.update();
    elevatorAsDcMotor.setTargetPosition(1380);
    elevatorAsDcMotor.setMode("RUN_TO_POSITION");
    elevatorAsDcMotor.setVelocity(800);
    while (linearOpMode.opModeIsActive() && elevatorAsDcMotor.isBusy()) {
    }
    strafe(90, 200, 0.2);
    intake(1500);
    strafe(270, 200, 0.2);
  }
  while (elevatorAsDcMotor.getCurrentPosition() > 0) {
    elevatorAsDcMotor.setTargetPosition(0);
  }
  elevatorAsDcMotor.setPower(0);
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  initializeMotors();
  initializeTF();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    duckPos = findDuckPos(2000);
    telemetryAddTextData('key', duckPos);
    telemetry.update();
    strafe(180, 500, 0.5);
    strafe(270, 400, 0.5);
    strafe(90, 75, 0.3);
    strafe(0, 1200, 0.2);
    rotateCarousel(3500);
    strafe(180, 120, 0.5);
    strafe(270, 250, 0.5);
    strafe(180, 1020, 0.5);
    turnRobot(175, 'right');
    strafe(270, 100, 0.5);
    strafe(85, 580, 0.5);
    elevator(duckPos);
    strafe(270, 600, 0.5);
    strafe(0, 415, 0.5);
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function strafe(strafeAngle, strafeTime, motorSpeed) {
  Vertical = Math.sin(strafeAngle / 180 * Math.PI);
  horizontal = Math.cos(strafeAngle / 180 * Math.PI);
  internalStrafeTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  motorOffset = 0;
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalStrafeTimer) < strafeTime) {
    frontrightAsDcMotor.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
    backrightAsDcMotor.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
    frontleftAsCRServo.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
    backleftAsDcMotor.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
  }
  stopMotors();
}

/**
 * Describe this function...
 */
function initializeTF() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', true, true, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodAccess.initialize(vuforiaCurrentGameAccess, 0.6, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodAccess.activate();
  tfodAccess.setZoom(1, 16 / 9);
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
}

/**
 * Describe this function...
 */
function intake(intakeTime) {
  internalIntakeTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalIntakeTimer) < intakeTime) {
    intakeAsCRServo.setPower(-1);
  }
  intakeAsCRServo.setPower(0);
}

/**
 * Describe this function...
 */
function rotateCarousel(carouselTime) {
  internalCarouselTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  carouselAsCRServo.setPower(0);
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalCarouselTimer) < carouselTime) {
    carouselAsCRServo.setPower(-1);
  }
  carouselAsCRServo.setPower(0);
}

/**
 * Describe this function...
 */
function stopMotors() {
  internalStopTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalStopTimer) < 700) {
    frontleftAsCRServo.setPower(0);
    frontrightAsDcMotor.setPower(0);
    backleftAsDcMotor.setPower(0);
    backrightAsDcMotor.setPower(0);
  }
}

/**
 * Describe this function...
 */
function turnRobot(turnTime, turnDir) {
  internalTurnTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  while (elapsedTimeAccess.getMilliseconds(internalTurnTimer) < turnTime) {
    if (turnDir == 'left') {
      frontrightAsDcMotor.setPower(0.4);
      backleftAsDcMotor.setPower(-0.4);
    } else {
      backrightAsDcMotor.setPower(-0.4);
      frontleftAsCRServo.setPower(0.4);
    }
  }
  stopMotors();
}
