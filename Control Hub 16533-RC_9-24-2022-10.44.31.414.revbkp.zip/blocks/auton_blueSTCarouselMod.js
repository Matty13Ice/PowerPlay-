var strafeAngle, strafeTime, motorSpeed, carouselTime, turnTime, turnDir, internalCarouselTimer, internalTurnTimer, internalStopTimer, strafeYaw, Yaw_Angle, Vertical, horizontal, internalStrafeTimer, motorOffset, duckPos;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  initializeMotors();
  telemetryAddTextData('Ready!!', 'This doesn\'t use a camera, so yeah!');
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    telemetryAddTextData('key', duckPos);
    telemetry.update();
    strafe(150, 850, 0.5);
    turnRobot(1000, 'left');
    strafe(0, 1400, 0.3);
    strafe(270, 570, 0.16);
    rotateCarousel(3000);
    strafe(90, 300, 0.5);
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function strafe(strafeAngle, strafeTime, motorSpeed) {
  Vertical = Math.sin(strafeAngle / 180 * Math.PI);
  horizontal = Math.cos(strafeAngle / 180 * Math.PI);
  internalStrafeTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  motorOffset = 0;
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalStrafeTimer) < strafeTime) {
    frontrightAsDcMotor.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
    backrightAsDcMotor.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
    frontleftAsCRServo.setPower(((Vertical + horizontal) - motorOffset) * motorSpeed);
    backleftAsDcMotor.setPower(((Vertical - horizontal) + motorOffset) * motorSpeed);
  }
  stopMotors();
}

/**
 * Describe this function...
 */
function rotateCarousel(carouselTime) {
  internalCarouselTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  carouselAsCRServo.setPower(0);
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalCarouselTimer) < carouselTime) {
    carouselAsCRServo.setPower(1);
    frontrightAsDcMotor.setPower(-0.1);
    backleftAsDcMotor.setPower(-0.1);
    backrightAsDcMotor.setPower(-0.1);
    frontleftAsCRServo.setPower(-0.1);
  }
  carouselAsCRServo.setPower(0);
}

/**
 * Describe this function...
 */
function initializeMotors() {
  backrightAsDcMotor.setDirection("REVERSE");
  backleftAsDcMotor.setDirection("REVERSE");
  frontrightAsDcMotor.setDirection("REVERSE");
  frontrightAsDcMotor.setZeroPowerBehavior("FLOAT");
  backleftAsDcMotor.setZeroPowerBehavior("FLOAT");
  backrightAsDcMotor.setZeroPowerBehavior("FLOAT");
  elevatorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  elevatorAsDcMotor.setZeroPowerBehavior("BRAKE");
}

/**
 * Describe this function...
 */
function turnRobot(turnTime, turnDir) {
  internalTurnTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  while (elapsedTimeAccess.getMilliseconds(internalTurnTimer) < turnTime) {
    if (turnDir == 'left') {
      frontrightAsDcMotor.setPower(0.4);
      backleftAsDcMotor.setPower(-0.4);
    } else {
      backrightAsDcMotor.setPower(-0.4);
      frontleftAsCRServo.setPower(0.4);
    }
  }
  stopMotors();
}

/**
 * Describe this function...
 */
function stopMotors() {
  internalStopTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalStopTimer) < 700) {
    frontleftAsCRServo.setPower(0);
    frontrightAsDcMotor.setPower(0);
    backleftAsDcMotor.setPower(0);
    backrightAsDcMotor.setPower(0);
  }
}
