var stickMag, modifier_spd, speeed, Vertical, horizontal, pivot;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  frontrightAsDcMotor.setZeroPowerBehavior("FLOAT");
  backleftAsDcMotor.setZeroPowerBehavior("FLOAT");
  backrightAsDcMotor.setZeroPowerBehavior("FLOAT");
  frontrightAsDcMotor.setDirection("REVERSE");
  elevatorAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  elevatorAsDcMotor.setZeroPowerBehavior("BRAKE");
  elevatorAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  elevatorAsDcMotor.setTargetPosition(0);
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (true) {
        modifier_spd = 0.85;
      } else {
        modifier_spd = 1;
      }
      Vertical = motorSpeed(-(gamepad1.getLeftStickY() * modifier_spd));
      horizontal = motorSpeed(gamepad1.getLeftStickX() * modifier_spd);
      pivot = motorSpeed(gamepad1.getRightStickX() * modifier_spd);
      frontrightAsDcMotor.setPower(-pivot + (Vertical - horizontal));
      backrightAsDcMotor.setPower(pivot - (Vertical + horizontal));
      frontleftAsCRServo.setPower(pivot + Vertical + horizontal);
      backleftAsDcMotor.setPower(-pivot - (Vertical - horizontal));
      elevatorAsDcMotor.setPower(-0.75 * gamepad2.getRightStickY());
      if (gamepad2.getRightBumper()) {
        intakeAsCRServo.setDirection("FORWARD");
        intakeAsCRServo.setPower(1);
      } else if (gamepad2.getLeftBumper()) {
        intakeAsCRServo.setDirection("REVERSE");
        intakeAsCRServo.setPower(1);
      } else {
        intakeAsCRServo.setPower(0);
      }
      if (true) {
        if (gamepad2.getRightStickY() < -0.5) {
          elevatorAsDcMotor.setMode("RUN_TO_POSITION");
          elevatorAsDcMotor.setVelocity(1000);
          elevatorAsDcMotor.setTargetPosition(1400);
        }
        if (gamepad2.getRightStickY() > 0.5) {
          elevatorAsDcMotor.setMode("RUN_TO_POSITION");
          elevatorAsDcMotor.setVelocity(800);
          elevatorAsDcMotor.setTargetPosition(0);
        }
        if (Math.abs(gamepad2.getRightStickY()) < 0.4) {
          elevatorAsDcMotor.setPower(0);
        }
      } else {
      }
      if (gamepad2.getA()) {
        carouselAsCRServo.setPower(1);
      } else {
        carouselAsCRServo.setPower(0);
      }
      telemetry.addNumericData('RightStickY', gamepad1.getRightStickY());
      telemetry.addNumericData('front right', frontrightAsDcMotor.getPower());
      telemetry.addNumericData('front left', frontleftAsCRServo.getPower());
      telemetry.addNumericData('back right', backrightAsDcMotor.getPower());
      telemetry.addNumericData('back left', backleftAsDcMotor.getPower());
      telemetry.addNumericData('elevator power', elevatorAsDcMotor.getPower());
      telemetry.addNumericData('elevator height', elevatorAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
  }
}

/**
 * Describe this function...
 */
function motorSpeed(stickMag) {
  speeed = 0.65 * stickMag;
  if (Math.abs(stickMag) < 0.9) {
    speeed = 0.4 * stickMag;
  }
  if (Math.abs(stickMag) < 0.4) {
    speeed = 0;
  }
  return speeed;
}
