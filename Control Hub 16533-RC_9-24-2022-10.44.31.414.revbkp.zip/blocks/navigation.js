var IMU_Parameters, ElapsedTime, front_left_power, back_right_power, front_right_power, back_left_power, Yaw_Angle;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  backrightAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontrightAsDcMotor.setZeroPowerBehavior("BRAKE");
  backleftAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontleftAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontleftAsDcMotor.setDirection("REVERSE");
  backrightAsDcMotor.setDirection("REVERSE");
  IMU_Parameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setSensorMode(IMU_Parameters, "IMU");
  imuAsBNO055IMU.initialize(IMU_Parameters);
  telemetryAddTextData('Status', 'IMU initialized, calibration started.');
  telemetry.update();
  linearOpMode.sleep(1000);
  while (!IMU_Calibrated()) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetryAddTextData('Action needed:', 'Please press the start triangle');
  telemetry.update();
  linearOpMode.waitForStart();
  ElapsedTime = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  front_left_power = 0.3;
  back_right_power = 0.3;
  front_right_power = 0.3;
  back_left_power = 0.3;
  frontleftAsDcMotor.setDualPower(front_left_power, backrightAsDcMotor, back_right_power);
  frontrightAsDcMotor.setDualPower(front_right_power, backleftAsDcMotor, back_left_power);
  while (!(elapsedTimeAccess.getMilliseconds(ElapsedTime) >= 2000 || linearOpMode.isStopRequested())) {
    Yaw_Angle = orientationAccess.getThirdAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "XYZ", "DEGREES"));
    telemetry.addNumericData('Yaw angle', Yaw_Angle);
    if (Yaw_Angle < -5) {
      front_left_power = 0.1;
      back_right_power = 0.2;
    } else if (Yaw_Angle > 5) {
      front_left_power = 0.2;
      back_right_power = 0.1;
    } else {
      front_left_power = 0.3;
      back_right_power = 0.3;
    }
    telemetry.addNumericData('Front Left Power', front_left_power);
    telemetry.addNumericData('Back Right Power', back_right_power);
    telemetry.addNumericData('Front Right Power', front_right_power);
    telemetry.addNumericData('Back Left Power', back_left_power);
    frontleftAsDcMotor.setDualPower(front_left_power, backrightAsDcMotor, back_right_power);
    frontleftAsDcMotor.setDualPower(front_left_power, backrightAsDcMotor, back_right_power);
    telemetry.update();
    linearOpMode.sleep(200);
  }
  frontleftAsDcMotor.setDualPower(-0.2, backrightAsDcMotor, -0.2);
  while (!(Yaw_Angle <= -90 || linearOpMode.isStopRequested())) {
    Yaw_Angle = orientationAccess.getThirdAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "XYZ", "DEGREES"));
    telemetry.addNumericData('Yaw value', Yaw_Angle);
    telemetry.update();
  }
  backrightAsDcMotor.setDualPower(0, frontrightAsDcMotor, 0);
  backleftAsDcMotor.setDualPower(0, frontleftAsDcMotor, 0);
  linearOpMode.sleep(1000);
}

/**
 * Function that becomes true when gyro is calibrated and
 * reports calibration status to Driver Station in the meantime.
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
  return imuAsBNO055IMU.isGyroCalibrated();
}
