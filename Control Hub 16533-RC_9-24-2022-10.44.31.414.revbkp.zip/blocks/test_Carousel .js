/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      if (gamepad1.getA()) {
        carouselAsCRServo.setPower(1);
      }
      if (!gamepad1.getA()) {
        carouselAsCRServo.setPower(0);
      }
      telemetry.addNumericData('Carousel Power', carouselAsCRServo.getPower());
      telemetry.update();
    }
  }
}
