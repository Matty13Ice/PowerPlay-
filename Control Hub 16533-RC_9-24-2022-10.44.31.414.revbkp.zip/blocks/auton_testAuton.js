var driveTimer1, duckPos, pivot, strafeAngle, strafeTime, turnAngle, barcodeTimer, carouselRotationTimer, ArmTimer, IMU_Parameters, recog, strafeYaw, recogCenter, Yaw_Angle, Vertical, horizontal, ElapsedTime, internalStrafeTimer, deltaTurnAngle, sinDelta, motorOffset, front_left_power, back_right_power, front_right_power, back_left_power;

/**
 * Describe this function...
 */
function setBarcodeTimer() {
  barcodeTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
}

/**
 * Describe this function...
 */
function checkBarcodeTimer() {
  return elapsedTimeAccess.getMilliseconds(barcodeTimer) <= 3000 && duckPos == 'rightBarcode';
}

/**
 * Describe this function...
 */
function setCarouselTimer() {
  carouselRotationTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
}

/**
 * Describe this function...
 */
function checkCarouselTimer() {
  return elapsedTimeAccess.getMilliseconds(carouselRotationTimer) <= 2000;
}

/**
 * Describe this function...
 */
function initializeTF() {
  vuforiaCurrentGameAccess.initialize_withWebcam_2("Webcam 1", '', true, true, "NONE", 0, 0, 0, "XZY", 90, 90, 0, true);
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.7, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(1, 16 / 9);
  telemetryAddTextData('DS preview on/off', '3 dots, Camera Stream');
  telemetryAddTextData('>', 'Press Play to start');
  telemetry.update();
}

/**
 * Describe this function...
 */
function initializeMotors() {
  backrightAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontrightAsDcMotor.setZeroPowerBehavior("BRAKE");
  backleftAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontleftAsDcMotor.setZeroPowerBehavior("BRAKE");
  frontleftAsDcMotor.setDirection("REVERSE");
  backrightAsDcMotor.setDirection("REVERSE");
}

/**
 * Describe this function...
 */
function setArmTimer() {
  ArmTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
}

/**
 * Describe this function...
 */
function intializeIMU() {
  IMU_Parameters = bno055imuParametersAccess.create();
  bno055imuParametersAccess.setSensorMode(IMU_Parameters, "IMU");
  imuAsBNO055IMU.initialize(IMU_Parameters);
  telemetryAddTextData('Status', 'IMU initialized, calibration started.');
  telemetry.update();
  linearOpMode.sleep(1000);
  while (!false) {
    telemetryAddTextData('If calibration ', 'doesn\'t complete after 3 seconds, move through 90 degree pitch, roll and yaw motions until calibration complete ');
    telemetry.update();
    linearOpMode.sleep(1000);
  }
  telemetryAddTextData('Status', 'Calibration Complete');
  telemetryAddTextData('Action needed:', 'Please press the start triangle');
  telemetry.update();
}

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  initializeTF();
  intializeIMU();
  initializeMotors();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      displayDuckPos();
      setBarcodeTimer();
      while (checkBarcodeTimer()) {
        displayDuckPos();
      }
      strafe(270, null);
      stopMotors();
      rotateCarousel();
      while (checkCarouselTimer()) {
      }
      stopMotors();
      saveYawAngle();
      updateYawAngle();
      telemetry.update();
    }
  }
  tfodCurrentGameAccess.deactivate();
}

/**
 * Describe this function...
 */
function checkArmTimer() {
  return elapsedTimeAccess.getMilliseconds(ArmTimer) <= 5000;
}

/**
 * Function that becomes true when gyro is calibrated and
 * reports calibration status to Driver Station in the meantime.
 */
function IMU_Calibrated() {
  telemetryAddTextData('IMU Calibration Status', imuAsBNO055IMU.getCalibrationStatus());
  telemetryAddTextData('Gyro Calibrated', imuAsBNO055IMU.isGyroCalibrated() ? 'True' : 'False');
  telemetryAddTextData('System Status', imuAsBNO055IMU.getSystemStatus());
  return imuAsBNO055IMU.isGyroCalibrated();
}

/**
 * Describe this function...
 */
function checkDriveTimer1() {
  return elapsedTimeAccess.getMilliseconds(driveTimer1) <= 3000 && elevatorAsDcMotor.getCurrentPosition() < 2000;
}

/**
 * Describe this function...
 */
function setElevatorLevel(duckPos) {
}

/**
 * Describe this function...
 */
function findDuckPos() {
  duckPos = 'rightBarcode';
  var recog_list = JSON.parse(tfodCurrentGameAccess.getRecognitions());
  for (var recog_index in recog_list) {
    recog = recog_list[recog_index];
    recogCenter = (recog.Left + recog.Right) / 2;
    if (recog.Label == "Duck" && recog.Height >= 80) {
      if (recogCenter < recog.ImageWidth / 2) {
        duckPos = 'leftBarcode';
      } else {
        duckPos = 'centerBarcode';
      }
    }
  }
  return duckPos;
}

/**
 * Describe this function...
 */
function updateYawAngle() {
  while (!(Yaw_Angle <= -90 || linearOpMode.isStopRequested())) {
    Yaw_Angle = orientationAccess.getThirdAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "XYZ", "DEGREES"));
    telemetry.addNumericData('Yaw value', Yaw_Angle);
    telemetry.update();
  }
}

/**
 * Describe this function...
 */
function saveYawAngle() {
  while (!(elapsedTimeAccess.getMilliseconds(ElapsedTime) >= 2000 || linearOpMode.isStopRequested())) {
    Yaw_Angle = orientationAccess.getThirdAngle(imuAsBNO055IMU.getAngularOrientation("INTRINSIC", "XYZ", "DEGREES"));
    telemetry.addNumericData('Yaw angle', Yaw_Angle);
    if (Yaw_Angle < -5) {
      front_left_power = 0.1;
      back_right_power = 0.2;
    } else if (Yaw_Angle > 5) {
      front_left_power = 0.2;
      back_right_power = 0.1;
    } else {
      front_left_power = 0.3;
      back_right_power = 0.3;
    }
    telemetry.addNumericData('Front Left Power', front_left_power);
    telemetry.addNumericData('Back Right Power', back_right_power);
    telemetry.addNumericData('Front Right Power', front_right_power);
    telemetry.addNumericData('Back Left Power', back_left_power);
    frontleftAsDcMotor.setDualPower(front_left_power, backrightAsDcMotor, back_right_power);
    frontleftAsDcMotor.setDualPower(front_left_power, backrightAsDcMotor, back_right_power);
    telemetry.update();
    linearOpMode.sleep(200);
  }
}

/**
 * Describe this function...
 */
function rotateCarousel() {
  frontleftAsCRServo.setPower(1);
}

/**
 * Describe this function...
 */
function displayDuckPos() {
  duckPos = findDuckPos();
  telemetryAddTextData('duckPos', duckPos);
}

/**
 * Describe this function...
 */
function strafe(strafeAngle, strafeTime) {
  strafeYaw = Yaw_Angle;
  Vertical = Math.sin(strafeAngle / 180 * Math.PI);
  horizontal = Math.cos(strafeAngle / 180 * Math.PI);
  internalStrafeTimer = elapsedTimeAccess.create_withResolution("MILLISECONDS");
  while (linearOpMode.opModeIsActive() && elapsedTimeAccess.getMilliseconds(internalStrafeTimer) < strafeTime) {
    if (Yaw_Angle > strafeYaw + 5) {
      motorOffset = 0.2;
    } else if (Yaw_Angle < strafeYaw - 5) {
      motorOffset = -0.2;
    } else {
      motorOffset = 0;
    }
    frontrightAsDcMotor.setPower((Vertical - horizontal) + motorOffset);
    backrightAsDcMotor.setPower((Vertical + horizontal) - motorOffset);
    frontleftAsCRServo.setPower((Vertical + horizontal) - motorOffset);
    backleftAsDcMotor.setPower((Vertical - horizontal) + motorOffset);
  }
  stopMotors();
}

/**
 * Describe this function...
 */
function turnRobot(turnAngle) {
  deltaTurnAngle = turnAngle - Yaw_Angle;
  sinDelta = Math.sin(deltaTurnAngle / 180 * Math.PI);
  while (linearOpMode.opModeIsActive() && deltaTurnAngle >= 5 && deltaTurnAngle <= -5) {
    deltaTurnAngle = turnAngle - Yaw_Angle;
    sinDelta = Math.sin(deltaTurnAngle / 180 * Math.PI);
    frontrightAsDcMotor.setPower(-sinDelta);
    frontleftAsCRServo.setPower(sinDelta);
    backleftAsDcMotor.setPower(-sinDelta);
    backrightAsDcMotor.setPower(sinDelta);
  }
}

/**
 * Describe this function...
 */
function randomScrappedCode() {
  if (duckPos == 'leftBarcode') {
    telemetryAddTextData('Level', 'Bottom');
  } else if (duckPos == 'centerBarcode') {
    telemetryAddTextData('Level', 'Middle');
  } else {
    telemetryAddTextData('Level', 'Top');
  }
  telemetry.update();
}

/**
 * Describe this function...
 */
function stopMotors() {
  frontleftAsCRServo.setPower(0);
  frontrightAsDcMotor.setPower(0);
  backleftAsDcMotor.setDualPower(0, backrightAsDcMotor, 0);
}
