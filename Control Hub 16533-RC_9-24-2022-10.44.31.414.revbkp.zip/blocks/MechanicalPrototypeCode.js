var timePressed, rotations, motor_0_power, motor_1_power;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  servo0AsServo.setDirection("REVERSE");
  servo0AsServo.setPosition(0);
  timePressed = 0;
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      rotations = 537.7;
      motor0AsDcMotor.setMode("STOP_AND_RESET_ENCODER");
      motor0AsDcMotor.setTargetPosition(rotations);
      motor0AsDcMotor.setMode("RUN_TO_POSITION");
      motor0AsDcMotor.setZeroPowerBehavior("BRAKE");
      motor_0_power = gamepad1.getX();
      motor_1_power = gamepad1.getRightStickY();
      if (gamepad1.getX() && timePressed % 2 == 1) {
        motor0AsDcMotor.setTargetPosition(rotations);
        motor_0_power = 1;
      } else if (gamepad1.getX() && timePressed % 2 == 0) {
        motor0AsDcMotor.setTargetPosition(rotations);
        motor_0_power = -1;
      }
      if (!gamepad1.getX()) {
        motor_0_power = 0;
        timePressed = (typeof timePressed == 'number' ? timePressed : 0) + 1;
      }
      telemetry.addNumericData('motor 0', motor_0_power);
      telemetry.addNumericData('motor 1', motor_1_power);
      telemetry.addNumericData('servo 0', servo0AsServo.getPosition());
      telemetry.update();
      motor0AsDcMotor.setPower(motor_0_power);
    }
  }
}
