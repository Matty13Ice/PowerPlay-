var powerEle, rotationtime;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      elevatorAsDcMotor.setPower(-0.5 * gamepad1.getRightStickY());
      if (gamepad1.getY()) {
        intakeAsCRServo.setDirection("FORWARD");
        intakeAsCRServo.setPower(1);
      } else if (gamepad1.getX()) {
        intakeAsCRServo.setDirection("REVERSE");
        intakeAsCRServo.setPower(1);
      } else {
        intakeAsCRServo.setPower(0);
      }
    }
    telemetry.update();
  }
}
